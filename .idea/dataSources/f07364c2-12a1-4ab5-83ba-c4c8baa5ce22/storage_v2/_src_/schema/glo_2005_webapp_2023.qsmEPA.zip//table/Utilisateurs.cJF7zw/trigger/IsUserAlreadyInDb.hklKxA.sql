create definer = root@localhost trigger IsUserAlreadyInDb
    before insert
    on Utilisateurs
    for each row
BEGIN
    DECLARE email_exists INT;

    SELECT email INTO email_exists FROM Utilisateurs WHERE email = NEW.email;

    IF email_exists IN (SELECT email FROM Utilisateurs) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un utilisateur existe deja avec cet email';
    END IF;
END;

