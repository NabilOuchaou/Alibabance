create
    definer = root@localhost procedure CalculerCoutTotalPanier(IN p_email varchar(255), OUT p_totalPrice decimal(10, 2))
BEGIN
    DECLARE v_finished INTEGER DEFAULT 0;
    DECLARE v_idProduit INTEGER;
    DECLARE v_quantite INTEGER;
    DECLARE v_coutProduit DECIMAL(10, 2);
    DECLARE v_coutPanier DECIMAL(10, 2) DEFAULT 0;

    DECLARE panier_cursor CURSOR FOR
        SELECT id_produit, quantite FROM Paniers WHERE email = p_email;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_finished = 1;

    OPEN panier_cursor;
    read_loop: LOOP
        FETCH panier_cursor INTO v_idProduit, v_quantite;

        IF v_finished = 1 THEN
            LEAVE read_loop;
        END IF;

        SELECT cout_Produit INTO v_coutProduit
        FROM Inventaire WHERE id_produit = v_idProduit;

        SET v_coutPanier = v_coutPanier + (v_coutProduit * v_quantite);
    END LOOP;
    CLOSE panier_cursor;

    SET p_totalPrice = v_coutPanier;
end;

